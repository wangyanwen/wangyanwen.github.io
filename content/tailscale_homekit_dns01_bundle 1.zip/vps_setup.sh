\
#!/bin/bash
# VPS one-click setup: Headscale + AmneziaWG + Cloudflare DNS-01 certificate
# Usage: sudo bash vps_setup.sh <HS_DOMAIN> <WG_DOMAIN> <LE_EMAIL>

set -euo pipefail

HS_DOMAIN="$1"
WG_DOMAIN="$2"
LE_EMAIL="$3"

if [[ -z "$HS_DOMAIN" || -z "$WG_DOMAIN" || -z "$LE_EMAIL" ]]; then
  echo "Usage: sudo bash $0 <HS_DOMAIN> <WG_DOMAIN> <LE_EMAIL>"
  exit 1
fi

# Cloudflare API placeholder
export CF_Key="*"
export CF_Email="*"

echo "[1/6] Update system"
apt-get update -y && apt-get upgrade -y
apt-get install -y curl wget ufw docker.io docker-compose jq

echo "[2/6] Install acme.sh for Cloudflare DNS-01"
curl https://get.acme.sh | sh
~/.acme.sh/acme.sh --set-default-ca --server letsencrypt
~/.acme.sh/acme.sh --register-account -m "$CF_Email"

echo "[3/6] Issue certificates using Cloudflare DNS-01"
~/.acme.sh/acme.sh --issue --dns dns_cf -d "$HS_DOMAIN" --keylength ec-256
~/.acme.sh/acme.sh --issue --dns dns_cf -d "$WG_DOMAIN" --keylength ec-256

mkdir -p /etc/ssl/$HS_DOMAIN /etc/ssl/$WG_DOMAIN
~/.acme.sh/acme.sh --install-cert -d "$HS_DOMAIN" --ecc --fullchain-file /etc/ssl/$HS_DOMAIN/fullchain.cer --key-file /etc/ssl/$HS_DOMAIN/$HS_DOMAIN.key
~/.acme.sh/acme.sh --install-cert -d "$WG_DOMAIN" --ecc --fullchain-file /etc/ssl/$WG_DOMAIN/fullchain.cer --key-file /etc/ssl/$WG_DOMAIN/$WG_DOMAIN.key

echo "[4/6] Install Headscale"
ARCH="$(dpkg --print-architecture)"
HS_VER="0.23.0"
wget -O /tmp/headscale.deb "https://github.com/juanfont/headscale/releases/download/v${HS_VER}/headscale_${HS_VER}_linux_${ARCH}.deb"
dpkg -i /tmp/headscale.deb
mkdir -p /etc/headscale
cat >/etc/headscale/config.yaml <<EOF
server_url: https://${HS_DOMAIN}:8443
listen_addr: 127.0.0.1:8080
noise:
  private_key_path: /var/lib/headscale/noise_private.key
derp:
  server:
    enabled: false
acls:
  - action: accept
    src: ["*"]
    dst: ["*:*"]
log:
  level: info
EOF
systemctl enable headscale
systemctl restart headscale

echo "[5/6] Deploy AmneziaWG (host network, 443/TCP+UDP)"
mkdir -p /opt/amneziawg
cat >/opt/amneziawg/docker-compose.yml <<EOF
version: "3.8"
services:
  amneziawg:
    image: amnezia/amneziawg:latest
    container_name: amneziawg
    restart: unless-stopped
    network_mode: host
    environment:
      WG_PORT: "443"
      WG_DOMAIN: "${WG_DOMAIN}"
      WG_PROTOCOL: "https"
    volumes:
      - /opt/amneziawg/config:/config
EOF
docker compose -f /opt/amneziawg/docker-compose.yml up -d

echo "[6/6] Firewall and preauth key"
ufw allow 443/tcp; ufw allow 443/udp; ufw allow 8443/tcp; yes | ufw enable || true
headscale users create default || true
AUTH_JSON=$(headscale preauthkeys create -u default --reusable --ephemeral --expiration 2160h --output json)
AUTH_KEY=$(echo "$AUTH_JSON" | jq -r '.key')
echo "$AUTH_KEY" > /root/hs_authkey.txt
echo "Run 'sudo hs_make_qr.sh' to generate join QR code."
