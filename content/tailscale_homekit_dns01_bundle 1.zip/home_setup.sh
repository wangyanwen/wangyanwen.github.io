\
#!/bin/bash
# Home (Raspberry Pi/soft router) one-click: install Tailscale and advertise LAN routes
# Usage: sudo bash home_setup.sh <LOGIN_SERVER> <LAN_CIDR>

set -euo pipefail

LOGIN_SERVER="${1:-}"
LAN_CIDR="${2:-}"

if [[ -z "$LOGIN_SERVER" || -z "$LAN_CIDR" ]]; then
  echo "Usage: sudo bash $0 <LOGIN_SERVER> <LAN_CIDR>"
  exit 1
fi

echo "[1/3] Update system"
apt-get update -y && apt-get upgrade -y

echo "[2/3] Install Tailscale"
curl -fsSL https://tailscale.com/install.sh | sh

echo "[3/3] Enable IP forwarding & start Tailscale"
sysctl -w net.ipv4.ip_forward=1
sysctl -w net.ipv6.conf.all.forwarding=1
grep -q '^net.ipv4.ip_forward=1' /etc/sysctl.conf || echo 'net.ipv4.ip_forward=1' >> /etc/sysctl.conf
grep -q '^net.ipv6.conf.all.forwarding=1' /etc/sysctl.conf || echo 'net.ipv6.conf.all.forwarding=1' >> /etc/sysctl.conf

tailscale up --login-server "${LOGIN_SERVER}" --accept-dns=false --accept-routes="${LAN_CIDR}" || true
