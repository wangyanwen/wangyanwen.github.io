\
# Tailscale-like Home Access: VPS + Home (Cloudflare DNS-01)

## Files
- `vps_setup.sh`: VPS install Headscale + AmneziaWG + DNS-01 certificate
- `home_setup.sh`: Home install Tailscale + advertise LAN routes
- `README.txt`: usage instructions

## Quick start
1. Add DNS records in Cloudflare:
   - HS_DOMAIN -> VPS IP
   - WG_DOMAIN -> VPS IP

2. VPS:
```bash
sudo bash vps_setup.sh hs.example.com wg.example.com you@example.com
sudo hs_make_qr.sh    # generate QR code
```

3. Home device:
```bash
sudo bash home_setup.sh https://hs.example.com:8443 192.168.0.0/24
```

4. Approve node in Headscale and enjoy LAN access.
